Comsci-project-2nd-quarter
==========================

ComSci Group Project.

Members:
Jay Lopez
Luis Macatangay
Trisha Trajano
